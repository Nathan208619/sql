#!/bin/bash

sqlite3 company.db < 1.sql > q1.csv
sqlite3 company.db < 2.sql > q2.csv
sqlite3 company.db < 3.sql > q3.csv
sqlite3 company.db < 4.sql > q4.csv
sqlite3 company.db < 5.sql > q5.csv
sqlite3 company.db < 6.sql > q6.csv
sqlite3 company.db < 7.sql > q7.csv
