-- What is the name of the employee has the highest salary?
SELECT Fname, Lname, MAX(Salary)
FROM EMPLOYEE;