-- What are the names of the projects conducted in Houston? 
SELECT Pname
FROM PROJECT
WHERE Plocation='Houston';